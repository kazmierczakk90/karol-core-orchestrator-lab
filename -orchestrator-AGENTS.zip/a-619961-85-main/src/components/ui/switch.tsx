
import * as React from "react"
import * as SwitchPrimitives from "@radix-ui/react-switch"

import { cn } from "@/lib/utils"

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitives.Root
    className={cn(
      "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input dark:data-[state=unchecked]:bg-secondary/70",
      className
    )}
    {...props}
    ref={ref}
  >
    <SwitchPrimitives.Thumb
      className={cn(
        "pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0"
      )}
    />
  </SwitchPrimitives.Root>
))
Switch.displayName = SwitchPrimitives.Root.displayName

// Add a SwitchWithLabels component for easier use with labels
const SwitchWithLabels = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root> & {
    offLabel?: string;
    onLabel?: string;
  }
>(({ className, offLabel = "OFF", onLabel = "ON", ...props }, ref) => (
  <div className="flex items-center gap-2">
    {offLabel && <span className="text-xs text-gray-500 dark:text-gray-400">{offLabel}</span>}
    <Switch ref={ref} className={className} {...props} />
    {onLabel && <span className="text-xs text-gray-500 dark:text-gray-400">{onLabel}</span>}
  </div>
))
SwitchWithLabels.displayName = "SwitchWithLabels"

export { Switch, SwitchWithLabels }
