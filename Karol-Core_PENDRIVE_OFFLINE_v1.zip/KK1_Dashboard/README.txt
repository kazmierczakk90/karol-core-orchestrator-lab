
Karol-Core | KK1 Offline Demo System

To jest wersja demonstracyjna z interfejsem HTML + głosowym odczytem odpowiedzi agenta KK1.

Instrukcja użycia:
1. Uruchom plik start.html w folderze KK1_Dashboard (zalecana przeglądarka: Chrome/Edge).
2. Wpisz pytanie.
3. Kliknij przycisk "Odtwórz Głos", aby usłyszeć odpowiedź KK1 (działa offline, lokalnie).
4. Silnik głosu: Coqui TTS (lekki, profesjonalny styl głosu).

Do działania wymagany jest Python 3.8+ i paczki zainstalowane w tts_coqui.py.
