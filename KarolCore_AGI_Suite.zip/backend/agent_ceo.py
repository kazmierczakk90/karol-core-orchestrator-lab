
from backend.loader import load_onto, load_chk, load_map

class AGI_CEO:
    def __init__(self):
        self.beliefs = load_onto("backend/data/ceo_style_beliefs.onto")
        self.intent_rules = load_chk("backend/data/ceo_clarity_ruleset.chk")
        self.risk_map = load_map("backend/data/ceo_decision_risk_intent.map")

    def analyze(self, input_text: str) -> dict:
        clarity = self.check_clarity(input_text)
        if clarity != "clear":
            return {"status": "rejected", "reason": clarity}

        decision = self.map_decision(input_text)
        return {
            "status": "accepted",
            "decision": decision,
            "beliefs": self.beliefs[:3],
            "summary": f"CEO AGI analizuje: {input_text}"
        }

    def check_clarity(self, text: str) -> str:
        return "clear" if any(rule in text for rule in self.intent_rules) else "ambiguous"

    def map_decision(self, text: str) -> str:
        for key, value in self.risk_map.items():
            if key.lower() in text.lower():
                return f"Zidentyfikowano: '{key}' → Decyzja: {value}"
        return "Nie zidentyfikowano intencji strategicznej."
