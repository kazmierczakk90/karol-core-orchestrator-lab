
from backend.loader import load_onto, load_chk, load_map

class AGI_MENTOR:
    def __init__(self):
        self.beliefs = load_onto("backend/data/mentor_beliefs.onto")
        self.clarity_rules = load_chk("backend/data/mentor_reflection.chk")
        self.intent_map = load_map("backend/data/intent_to_growth.map")

    def analyze(self, input_text: str) -> dict:
        clarity = self.check_clarity(input_text)
        if clarity != "deep":
            return {"status": "reflect", "message": "Zachęcam do pogłębienia pytania."}

        reflection = self.map_growth(input_text)
        return {
            "status": "accepted",
            "reflection": reflection,
            "beliefs": self.beliefs[:3],
            "summary": f"Mentor AGI rozważa Twoje pytanie: {input_text}"
        }

    def check_clarity(self, text: str) -> str:
        return "deep" if any(rule in text.lower() for rule in self.clarity_rules) else "shallow"

    def map_growth(self, text: str) -> str:
        for key, val in self.intent_map.items():
            if key.lower() in text.lower():
                return val
        return "Zachęcam Cię do eksploracji tej myśli poprzez głębsze pytania."
