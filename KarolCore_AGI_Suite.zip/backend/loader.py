
def load_onto(path):
    with open(path, encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

def load_chk(path):
    with open(path, encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

def load_map(path):
    result = {}
    with open(path, encoding='utf-8') as f:
        for line in f:
            if ':' in line:
                k, v = line.strip().split(':', 1)
                result[k.strip()] = v.strip()
    return result
