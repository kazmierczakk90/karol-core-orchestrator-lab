
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from backend.agent_ceo import AGI_CEO
from backend.agent_mentor import AGI_MENTOR

app = FastAPI()
agent_ceo = AGI_CEO()
agent_mentor = AGI_MENTOR()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/agi")
async def analyze(request: Request):
    body = await request.json()
    input_text = body.get("input", "")
    agent_type = body.get("agent", "mentor")

    if agent_type == "ceo":
        return agent_ceo.analyze(input_text)
    else:
        return agent_mentor.analyze(input_text)
