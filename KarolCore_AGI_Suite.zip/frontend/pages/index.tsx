
import React, { useState } from "react";

export default function AGISuite() {
  const [agent, setAgent] = useState("mentor");
  const [input, setInput] = useState("");
  const [response, setResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const askAGI = async () => {
    setLoading(true);
    const res = await fetch("http://localhost:8000/agi", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input, agent }),
    });
    const data = await res.json();
    setResponse(data);
    setLoading(false);
  };

  return (
    <main style={{ padding: 24, maxWidth: 800, margin: "0 auto" }}>
      <h1 style={{ fontSize: "1.8rem", fontWeight: "bold" }}>KarolCore AGI Suite</h1>
      <label style={{ display: "block", margin: "16px 0 4px" }}>Wybierz Agenta:</label>
      <select value={agent} onChange={(e) => setAgent(e.target.value)}>
        <option value="mentor">Mentor AGI</option>
        <option value="ceo">CEO AGI</option>
      </select>
      <textarea
        rows={4}
        style={{ width: "100%", marginTop: 12 }}
        placeholder="Zadaj pytanie..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button onClick={askAGI} disabled={loading} style={{ marginTop: 12 }}>
        {loading ? "Myślenie..." : "Zadaj pytanie"}
      </button>
      {response && (
        <div style={{ background: "#f4f4f4", padding: 12, marginTop: 20 }}>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}
    </main>
  );
}
