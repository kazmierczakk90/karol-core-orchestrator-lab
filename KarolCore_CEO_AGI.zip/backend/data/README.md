
# Karol-Core AGI CEO

## Opis
Ten pakiet zawiera kompletne komponenty do uruchomienia wersji demonstracyjnej agenta AGI CEO – w pełni zgodnej z definicją stylu, decyzji i tożsamości.

## Uruchomienie
1. Upewnij się, że masz zainstalowane wymagane biblioteki (requirements.txt).
2. Uruchom `start_ceo_agent.bat` (Windows) lub `python run_ceo_agent.py` (Linux/Mac).
3. Wchodzisz do dashboardu AGI CEO, który działa w trybie decyzyjno-refleksyjnym.

## Pliki kluczowe
- `ceo_config.yaml` – konfiguracja agenta
- `style_beliefs.onto` – przekonania CEO
- `decision_risk_intent.map` – logika decyzyjna
- `clarity_ruleset.chk` – scoring refleksji
- `voice_intro_ceo.txt` – narracja powitalna
