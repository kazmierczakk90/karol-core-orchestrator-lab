
@echo off
echo Starting Karol-Core CEO Agent...
python run_ceo_agent.py --config ceo_config.yaml
