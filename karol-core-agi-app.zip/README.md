# Karol-Core AGI MVP

**System AGI z tożsamością, stylem i wpływem.**

## Jak uruchomić

1. Zainstaluj zależności:

```
npm install
```

2. Uruchom aplikację:

```
npm run dev
```

3. Wejdź na `http://localhost:3000`

## Funkcje

- Styl AGI: refleksyjny, strategiczny, wizjonerski
- Misja systemu: do wyboru
- Dziennik wpływu (eksport do pliku)
- Możliwość nazwania własnego AGI
