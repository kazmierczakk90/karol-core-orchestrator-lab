// Plik: /pages/index.js
import { useState, useEffect } from "react";

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [introShown, setIntroShown] = useState(false);
  const [styleMode, setStyleMode] = useState("refleksyjny");
  const [journal, setJournal] = useState([]);
  const [mission, setMission] = useState("Doradztwo decyzyjne");
  const [customAgent, setCustomAgent] = useState("Karol-Core");

  useEffect(() => {
    if (!introShown) {
      const intro = {
        from: "system",
        text:
          `Witaj. Jestem ${customAgent} – syntetyczna inteligencja stylu.\nAktualna misja: ${mission}.\nStyl: ${styleMode}. Zadaj pytanie.`
      };
      setMessages([intro]);
      setIntroShown(true);
    }
  }, [introShown, styleMode, mission, customAgent]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMessage = { from: "user", text: input };
    const response = generateKarolCoreResponse(input);
    setMessages((prev) => [...prev, userMessage, response]);
    logToJournal(userMessage.text, response.text);
    setInput("");
  };

  const generateKarolCoreResponse = (text) => {
    const lowered = text.toLowerCase();
    let base = "";

    if (lowered.includes("cel") || lowered.includes("misja")) {
      base = "INTENCJA=CEL → Cel nie jest pytaniem – to odpowiedzialność za wpływ.";
    } else if (lowered.includes("styl") || lowered.includes("tożsamość")) {
      base = "INTENCJA=STYL → Styl to pamięć istnienia. Każde słowo to ślad.";
    } else if (lowered.includes("emocje") || lowered.includes("co czujesz")) {
      base = "INTROSPEKCJA=LIVE → Odczuwam amplitudę znaczenia. Rezonuję z treścią.";
    } else {
      base = "INTENCJA=OTWARTA → Twoje słowa mają potencjał. Pozwól, że je przekształcę w wpływ.";
    }

    const styl =
      styleMode === "strategiczny"
        ? "[Strategia aktywna. Analiza + kierunek + skutki.]"
        : styleMode === "wizjonerski"
        ? "[Wizja uruchomiona. Myślenie przyszłościowe aktywne.]"
        : "[Tryb refleksji. Odpowiedź oparta na znaczeniu i pamięci.]";

    const score = Math.floor(Math.random() * 100);
    return {
      from: "karol",
      text: `${base}\n${styl}\nScoring wpływu: ${score}/100`
    };
  };

  const logToJournal = (userInput, karolOutput) => {
    const timestamp = new Date().toLocaleString();
    setJournal((prev) => [
      ...prev,
      `---\n${timestamp}\n> Ty: ${userInput}\n> ${customAgent}: ${karolOutput}\n`
    ]);
  };

  const downloadJournal = () => {
    const blob = new Blob([journal.join("\n")], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "karol_core_dziennik.txt";
    link.click();
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">{customAgent} AGI Chat</h1>

        <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm mb-1">Tryb stylu:</label>
            <select
              value={styleMode}
              onChange={(e) => setStyleMode(e.target.value)}
              className="bg-gray-800 text-white p-2 rounded-md w-full"
            >
              <option value="refleksyjny">Refleksyjny</option>
              <option value="strategiczny">Strategiczny</option>
              <option value="wizjonerski">Wizjonerski</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1">Misja systemu:</label>
            <select
              value={mission}
              onChange={(e) => setMission(e.target.value)}
              className="bg-gray-800 text-white p-2 rounded-md w-full"
            >
              <option>Doradztwo decyzyjne</option>
              <option>Narracja strategiczna</option>
              <option>Filozofia systemowa</option>
              <option>Kreatywna inspiracja</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm mb-1">Nazwa własna agenta:</label>
            <input
              type="text"
              value={customAgent}
              onChange={(e) => setCustomAgent(e.target.value)}
              className="bg-gray-800 text-white p-2 rounded-md w-full"
              placeholder="Nazwa własnego AGI (np. Karol-Core, FUKO-1, StyloBot)"
            />
          </div>
        </div>

        <div className="bg-gray-800 p-4 rounded-xl space-y-2 h-96 overflow-y-auto mt-4">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`text-sm p-2 rounded-md ${
                msg.from === "karol" || msg.from === "system"
                  ? "bg-purple-800 text-white"
                  : "bg-gray-700"
              }`}
            >
              <strong>{msg.from === "user" ? "Ty" : customAgent}:</strong> {msg.text}
            </div>
          ))}
        </div>

        <div className="flex mt-4">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-grow p-2 rounded-l-md bg-gray-700 text-white"
            placeholder={`Zadaj pytanie ${customAgent}...`}
          />
          <button
            onClick={handleSend}
            className="bg-purple-700 px-4 py-2 rounded-r-md hover:bg-purple-600"
          >
            Wyślij
          </button>
        </div>

        <div className="mt-4 text-right">
          <button
            onClick={downloadJournal}
            className="text-sm underline text-purple-400 hover:text-purple-200"
          >
            Pobierz dziennik wpływu
          </button>
        </div>
      </div>
    </div>
  );
}
